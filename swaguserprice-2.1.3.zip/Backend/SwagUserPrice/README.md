# Customer-specific prices

[![Software License](https://img.shields.io/badge/license-MIT-brightgreen.svg?style=flat-square)](LICENSE.md)

## Description
Define a specific product price for each customer

## License

The MIT License (MIT). Please see [License File](LICENSE) for more information.
